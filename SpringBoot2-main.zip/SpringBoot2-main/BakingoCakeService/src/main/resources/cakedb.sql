  create database cakedb;
  use cakedb;
  
  create table cakeflavor(
  flavor varchar(30),
  price int);
 
 
  create table orders(
  orderId int,
  selectedCake int,
  flavor varchar(30),
  flavorRate int,
  includeCandles int,
  includeinscription int,
  theinscription varchar(30),
  name varchar(30),
  phonenumber varchar(10),
  address varchar(20),
  price double);
  
  insert into cakeflavor values ("None($0)", 0),("Custard($5)", 5),("Raspberry($10)", 10),
  ("Pineapple($5)", 5),("Cherry($6)", 6),("Apricot($8)", 8),("Buttercream($7)", 7),
  ("Chocolate($10)", 10);