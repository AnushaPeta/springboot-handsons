package com.cognizant.bakingo.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;

import com.cognizant.bakingo.bean.Cake;
@Repository
public class CakeDao {
	
	@Autowired
	JdbcTemplate template;
	public CakeDao() {
		
	}
	
	public Map<String, Integer> getCakes(){
		return template.query("select * from cakeflavor", new ResultSetExtractor<Map<String, Integer>>() {
			@Override
			public Map<String, Integer> extractData(ResultSet rs) throws SQLException, DataAccessException {

				Map<String, Integer> flavorList = new LinkedHashMap<>();
				while (rs.next()) {
					flavorList.put(rs.getString(1), rs.getInt(2));
				}
				return flavorList;
			}
		});
	}
	
	public void addOrder(int id, Cake cake) {
		template.update("INSERT into orders VALUES (?,?,?,?,?,?,?,?,?,?,?)",new Object[] {id,cake.getSelectedcake(),cake.getFlavor(),cake.getFlavorRate(),cake.getIncludeCandles(),cake.getIncludeinscription(),cake.getTheinscription()
				,cake.getName(),cake.getPhonenumber(),cake.getAddress(),cake.getPrice()});
	}

}
